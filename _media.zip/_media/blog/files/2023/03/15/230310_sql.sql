select * from city;

-- IN 연산자 사용
SELECT Name, CountryCode, District
FROM city
WHERE District IN (SELECT Name FROM city);

-- ANY 연산자 사용
SELECT ID, Name, CountryCode, District, Population
FROM city
WHERE Population > ANY(SELECT population
FROM city WHERE Name = 'Kabul');

-- ALL 연산자 사용
SELECT ID, Name, CountryCode, District, Population
FROM city
WHERE Population > ALL (SELECT Population
FROM city WHERE Name = 'Sydney');
-- 대소문자 구분은 안하는 것으로 판단
SELECT * FROM city;
-- EXISTS 연산자 사용
SELECT A.Name, A.Population
FROM country A WHERE EXISTS
(SELECT 1 FROM city B WHERE A.Name = B.Name
OR B.Name = "Dubai");

-- GROUP BY 구문 사용
SELECT Name, District
FROM city
GROUP BY CountryCode
-- HAVING Population > 100000;